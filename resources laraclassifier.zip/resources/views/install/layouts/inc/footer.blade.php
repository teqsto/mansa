<footer class="main-footer">
	<div class="footer-content pt-0" style="border: 0; background-color: inherit;">
		<div class="container">
			<div class="row">
				
				<div class="col-xl-12 col-md-12">
					<div class="text-center">
						&copy; {{ date('Y') }} <a href="{{ url('/') }}">{{ strtolower(getDomain()) }}</a>
					</div>
				</div>

			</div>
		</div>
	</div>
</footer>
