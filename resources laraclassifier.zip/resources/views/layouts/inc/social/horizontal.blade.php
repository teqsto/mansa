<div class="text-center mt-4 mb-4 ms-0 me-0">
	<button class='btn btn-fb share s_facebook'><i class="fab fa-facebook"></i> </button>&nbsp;
	<button class='btn btn-tw share s_twitter'><i class="fab fa-twitter"></i> </button>&nbsp;
	<button class='btn btn-wa share s_whatsapp'><i class="fab fa-whatsapp"></i> </button>&nbsp;
	<button class='btn btn-lkin share s_linkedin'><i class="fab fa-linkedin"></i> </button>
</div>