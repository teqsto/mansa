{{-- expand/minimize button column --}}
<td class="details-control text-center cursor-pointer">
	<i class="far fa-plus-square details-row-button cursor-pointer" data-entry-id="{{ $entry->getKey() }}"></i>
</td>