{{-- email link --}}
<td><a href="mailto:{{ $entry->{$column['name']} }}">{{ $entry->{$column['name']} }}</a></td>