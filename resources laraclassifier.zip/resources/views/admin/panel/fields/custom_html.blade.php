{{-- used for heading, separators, etc --}}
<div @include('admin.panel.inc.field_wrapper_attributes') >
	{!! $field['value'] !!}
</div>