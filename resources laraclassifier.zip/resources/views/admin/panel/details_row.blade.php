<div class="mt-10 mb-10 ps-10 pe-10 pt-10 pb-10">
    <div class="flex-row d-flex justify-content-center">
        <div class="col-md-11">
            {{ trans('admin.details_row') }}
        </div>
    </div>
</div>
