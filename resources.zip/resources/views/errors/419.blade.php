@extends('errors::minimal')

@section('title', __('messages.t_page_expired_title'))
@section('code', '419')
@section('message', __('messages.t_page_expired_message'))
