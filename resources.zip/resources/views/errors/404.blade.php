@extends('errors::minimal')

@section('title', __('messages.t_not_found_title'))
@section('code', '404')
@section('message', __('messages.t_not_found_message'))
