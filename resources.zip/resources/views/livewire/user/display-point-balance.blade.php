@if (isEnablePointSystem())
<p class="text-xs text-green-600">Balance: {{ auth()->user()->wallet?->points ?? 0 }} {{getPointSystemSetting('short_name') }}</p>
@endif