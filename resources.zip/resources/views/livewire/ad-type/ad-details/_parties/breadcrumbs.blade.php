<div class="container mx-auto md:px-4 px-2 py-1 mt-5">
    <x-filament::breadcrumbs :breadcrumbs="$breadcrumbs" />
</div>
