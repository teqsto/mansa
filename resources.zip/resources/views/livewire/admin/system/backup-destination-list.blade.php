<div wire:poll.{{ $this->interval() }}>
	{{ $this->table }}
</div>
