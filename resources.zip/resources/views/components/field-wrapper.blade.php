<div>
    {{ $slot }}
</div>
