<div class="fi-ta-col-wrp">
    <!--[if BLOCK]><![endif]-->
    <div class="flex w-full disabled:pointer-events-none justify-start text-start">
        <div class="fi-ta-image px-3 py-4">
            <!--[if BLOCK]><![endif]-->
            <div class="flex items-center gap-x-2.5">
                <div class="flex gap-1.5">
                    <!--[if BLOCK]><![endif]-->
                    <img
                        src="{{$getRecord()->modifiable->getUrl()}}" style="height: 2.5rem;"
                        class="max-w-none object-cover object-center ring-white dark:ring-gray-900">
                    <!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]-->
                    <!--[if ENDBLOCK]><![endif]-->
                </div>

                <!--[if BLOCK]><![endif]-->
                <!--[if ENDBLOCK]><![endif]-->
            </div>
            <!--[if ENDBLOCK]><![endif]-->
        </div>

    </div>
    <!--[if ENDBLOCK]><![endif]-->
</div>
